#append----function used to join 2 series
import numpy as np
import pandas as pd
a=pd.Series([1,2,3,4,5])
b=pd.Series([4,5,6,7,8])
c=a._append(b,ignore_index=True)
print(c)