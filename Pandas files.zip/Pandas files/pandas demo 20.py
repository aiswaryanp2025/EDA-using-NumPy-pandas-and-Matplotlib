#1. Age mxm 2 emp fname ,lname,age,phno
#2.age min 1 emp fname ,lname,age,phno
#3.Chennai work age max  1 emp fname,lname,age

#Heirarchy order  loc   sort  colname head or tail

import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/sample4.txt",sep=',',header=None)
df.columns=['id','fname','lname','age','phno','location']
print(df)
print('_'*500)
#1.
df1=df.sort_values(by='age',ascending=False) \
       [['fname','lname','age','phno']].head(2)
print(df1)

print('_'*500)
#2.
df2=df.sort_values(by='age') \
       [['fname','lname','age','phno']].head(1)
print(df2)

print('_'*500)
#3.
df3=df.loc[df['location']=='Chennai']\
      .sort_values(by='age',ascending=False)\
      [['fname','lname','age','phno']].head(1)
print(df3)