#How to remove duplicate rows ?
import numpy as np
import pandas as pd
lst=[[101,'Aiswarya','N.P',25,'Data Analyst',30000],
     [102,'Anjali','K',26,'Chemist',35000],
     [103,'Athira','T.N',25,'Teacher',37000],
     [104,'Prayag','Madhu',27,'Software engineer',60000],
     [105,'Sarath','Krishnan',25,'Cloud engineer',38000],
     [106,'Sidharth','R',25,'Data Analyst',50000],
     [107,'Ashitha','Basheer',26,'Doctor',70000],
     [108,'Sreelekha','k',26,'Data scientist',100000],
     [105,'Sarath','Krishnan',25,'Cloud engineer',38000],
     [106,'Sidharth','R',25,'Data Analyst',50000],
     [107,'Ashitha','Basheer',26,'Doctor',70000],
     [101,'Aiswarya','T',25,'Data Analyst',30000]]


df=pd.DataFrame(lst)
df.columns=['id','fname','lname','age','prof','salary']
print(df)

#Drop duplicates ----used to remove duplicate rows
df1=df.drop_duplicates()
print(df1)