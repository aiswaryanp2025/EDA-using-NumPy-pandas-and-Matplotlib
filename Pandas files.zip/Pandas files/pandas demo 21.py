import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)
print('-'*1000)
#1 Age above 50 fname,lname,age,prof
df1=df.loc[df['age']>50] [['fname','lname','age','prof']]
print(df1)

print('-'*1000)
#2.Age range 25 to 40 fname ,lname,age,prof
df2=df.loc[(df ['age']>=25) & (df['age']<=40)] [['fname','lname','age','prof']]
print(df2)

print('-'*1000)
#3.India work,fname,lname,age,prof
df3=df.loc[df['location']=='india'] [['fname','lname','age','prof']]
print(df3)

print('-'*1000)
#4.India work and age above 50 ,fname,lname,age,prof
df4=df.loc[(df['location']=='india')&(df['age']>50)] [['fname','lname','age','prof']]
print(df4)

print('-'*1000)
#5.Age mxm 10 emp  fname,lname,age,prof
df5=df.sort_values(by='age',ascending=False)[['fname','lname','age','prof']].head(10)
print(df5)

print('-'*1000)
#6.Age min  6 emp  fname,lname,age,prof
df6=df.sort_values(by='age')[['fname','lname','age','prof']].head(6)
print(df6)

print('-'*1000)
#7.uk work and age below 40 fname,lname ,age
df7=df.loc[(df['location']=='uk') & (df['age']<40)] [['fname','lname','age']]
print(df7)

print('-'*1000)
#8.India work and prof doctor fname lname age
df8=df.loc[(df['location']=='india') & (df['prof']=='Doctor')] [['fname','lname','age']]
print (df8)

print('-'*1000)
#9.India work ,age maxm 3 emp fname,lname,age,prof
df9=df.loc[df['location']=='india'].sort_values(by='age',ascending=False) [['fname','lname','age','prof']].head(3)
print(df9)

print('-'*1000)
#10.India work ,age minimum 2 emp fname lname age
df10=df.loc[df['location']=='india'].sort_values(by='age')[['fname','lname','age']].head(2)
print(df10)

print('-'*1000)
#11.India work and prof doctor age minimum 1 emp fname,lname,age
df11=df.loc[(df['location']=='india') & (df['prof']=='Doctor')] .sort_values(by='age')[['fname','lname','age']].head(1)
print (df11)

print('-'*1000)
#12.pilot prof,age max 2 emp,fname,lname,age
df12=df.loc[df['prof']=='Pilot'].sort_values(by='age',ascending=False)[['fname','lname','age']].head(2)
print(df12)

print('-'*1000)
#13.pilot prof age min 1 emp full details
df13=df.loc[df['prof']=='Pilot'].sort_values(by='age')[['fname','lname','age','prof','location']].head(1)
print(df13)

