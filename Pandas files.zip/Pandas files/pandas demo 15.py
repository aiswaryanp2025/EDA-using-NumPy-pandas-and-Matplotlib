import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
x=df.iloc[:,:-1]
y=df.iloc[:,-1]
print(x)
print(y)