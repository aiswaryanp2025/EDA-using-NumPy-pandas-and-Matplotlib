#Data frame

#Create a nest list having employee id ,fname,lname,age,prof ,salary --7 emp

import numpy as np
import pandas as pd
lst=[[101,'Aiswarya','N.P',25,'Data Analyst',30000,'Thrissur'],
     [102,'Anjali','K',26,'Chemist',35000,'Chelakkara'],
     [103,'Athira','T.N',25,'Teacher',37000,'Chelakkara'],
     [104,'Prayag','Madhu',27,'Software engineer',60000,'Vadakara'],
     [105,'Sarath','Krishnan',25,'Cloud engineer',38000,'Mannuthy'],
     [106,'Sidharth','R',25,'Data Analyst',50000,'Palakkad'],
     [107,'Ashitha','Basheer',26,'Doctor',70000,'Chelakkara'],
     [108,'Sreelekha','k',26,'Data scientist',100000,'Karumathra']]
df=pd.DataFrame(lst)
df.columns=['id','fname','lname','age','prof','salary','location']
# print(df.head())
# print('-'*1000)
# print(df.tail())

# print(df.describe())
# print('-'*1000)
# #if we have to describe object values
# print(df.describe(include='O'))
# print('-'*1000)
# print(df.describe(include='all'))

#How to drop a column

df1=df.drop(['lname'],axis=1)
print(df1)




