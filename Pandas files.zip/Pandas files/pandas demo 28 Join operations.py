#Joining operations

# Inner joining
# table formed by combing common data in 2 tables

# Left outer join

# Right outer join

# Full outer join

import numpy as np
import pandas as pd
lst1=[[101,'Aiswarya','N.P',25],
     [102,'Adithya','C',21],
     [103,'Amrutha','S',23],
     [104,'Ashitha','Basheer',26],
     [105,'Anjali','K',26]]
df1=pd.DataFrame(lst1)
df1.columns=['id','fname','lname','age']
print(df1)
print('-'*500)
lst2=[['Data Analyst',103,'Thrissur',25000],
      ['Data Scientist',104,'Feroke', 25000],
      ['Big Data', 105, 'Shornur', 27000],
      ['Doctor', 106, 'Chelakkara', 55000],
      ['chemist', 107, 'Nattinchira', 30000]]
df2=pd.DataFrame(lst2)
df2.columns=['prof','id','location','salary']
print(df2)
print('-'*500)

#Inner join
df3=pd.merge(df1,df2,on='id',how='inner')
print(df3)

# Big data profession---prof fname,lname,age
df4=pd.merge(df1,df2,on='id',how='inner') \
      .loc[df2['prof']=='Big Data']\
       [['fname','lname','age']]
print(df4)

#2 id match---Age max 1 employee fname,lname,age,prof,salary

df5=pd.merge(df1,df2,on='id',how='inner')\
    .sort_values(by='age',ascending=False)\
    [['fname','lname','age','prof','salary']]\
    .head(1)
print(df5)
