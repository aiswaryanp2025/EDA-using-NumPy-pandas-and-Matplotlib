import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer5_windows.csv")
print(df)

# 1.Find total row count
print(df.shape[0])
# 2.Each prof count===count desc
df2=df.groupby('prof')['prof'].count()\
      .sort_values(ascending=False)
print(df2)
# 3.India work each prof count===count desc
df3=df.loc[df['loc']=='india']\
      .groupby('prof')['prof'].count()\
      .sort_values(ascending=False)
print(df3)
# 4.Each location,min age===age desc
df4=df.groupby('loc')['age'].min()\
      .sort_values(ascending=False)
print(df4)
# 5.Each location ,min age====age asc
df5=df.groupby('loc')['age'].min()
print(df5)
# 6.Each prof,total salary===salary desc
df6=df.groupby('prof')['salary'].sum().sort_values(ascending=False)
print(df6)
# 7.India,each prof min age ===age desc
df7=df.loc[df['loc']=='india'].groupby('prof')['age'].min().sort_values(ascending=False)
print(df7)
# 8.Us work,each prof avg salary===salary desc
df8=df.loc[df['loc']=='us'].groupby('prof')['salary'].mean().sort_values(ascending=False)
print(df7)
# 9.India work and age above 25 each prof avg salary
df9=df.loc[(df['loc']=='india')&(df['age']>25)].groupby('prof')['salary'].mean()
print(df9)