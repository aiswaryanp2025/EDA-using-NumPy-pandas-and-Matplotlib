import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)

df=pd.read_csv("C:/Users/aiswa/Downloads/txn_windows.csv" )
print(df)

df=pd.read_csv("C:/Users/aiswa/Downloads/movies_cleaned_pandas.csv",sep=',',header=None )
df.columns=['id','movie_name','year','rating','duration']
print(df)