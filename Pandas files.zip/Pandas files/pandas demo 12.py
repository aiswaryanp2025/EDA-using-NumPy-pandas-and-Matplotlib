# external file ---> dataframe
import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/sample4.txt",sep=',',header=None)
df.columns=['id','fname','lname','age','phno','location']
print(df)

# print(df.ndim)
# print(df.shape)
# print(df.head())
# print(df.tail())
# print(df.dtypes)
# print(df.columns)
print('-'*1000)

#how to select wanted columns only from dataframe
df1=df[['fname','lname','age','phno']]
print(df1)

print('-'*1000)
#collect first 3 employees fname,lname,age,phno

df2=df[['fname','lname','age','phno']].head(3)
print(df2)

print('-'*1000)

df2=df[['fname','lname','age']].tail(2)
print(df2)