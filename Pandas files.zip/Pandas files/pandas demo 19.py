import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/sample4.txt",sep=',',header=None)
df.columns=['id','fname','lname','age','phno','location']
print(df)
print('_'*500)

#we can order datas in given data frame

#sort_values()----is the function to order

#syntax----newdfname=old_dfname.sort_values(by='colname')
df1=df.sort_values(by='age')
print(df1)

print('_'*500)
#for descending order
df2=df.sort_values(by='age',ascending=False)
print(df2)

print('_'*500)

df3=df.sort_values(by='lname',ascending=False)
print(df3)