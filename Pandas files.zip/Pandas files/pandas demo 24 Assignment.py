import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)
print(df.shape)
print(df.columns)
# head
print(df.head())
# tail
print(df.tail())
# datatypes
print(df.dtypes)
# no of missing values
print(df.isna().sum())
# filling
print(df.fillna('india'))

# 1. Find Row count
df1=(df.shape[0])
print(df1)

# 2.Remove duplicates rows and find total row count
df2=df.drop_duplicates().shape[0]
print(df2)

# 3.Age maximum 10 fname,lname,prof,loc
df3=df.sort_values(by='age',ascending=False) [['fname','lname','prof','location']].head(10)
print(df3)

#4.Age minimum 5 employees fname,lname,prof,loc
df4=df.sort_values(by='age') [['fname','lname','prof','location']].head(5)
print(df4)

# 5. Each location count  [count desc order]
df5=df.groupby('location')['location'].count().sort_values(ascending=False)
print(df5)

#6. Full data
df6=df.loc[df['location']=='australia'] [['id','fname','lname','age','prof','location']]
print(df6)

#7. Each age group count [count desc order]
df7=df.groupby('age')['age'].count().sort_values (ascending=False)
print(df7)

#8. Each profession count [count desc order]

df8=df.groupby('prof')['prof'].count().sort_values (ascending=False)
print(df8)

# 9. India work
#
#           A. Row count
df9a=df.loc[df['location']=='india'].shape[0]
print(df9a)
#           B. Each profession count [count desc order]
df9b=df.loc[df['location']=='india'].groupby('prof')['prof'].count().sort_values(ascending=False)
print(df9b)
#           C. Age mxm 3 employees fname,lname,age,prof
df9c=df.loc[df['location']=='india'].sort_values(by='age',ascending=False) [['fname','lname','age','prof']].head(3)
print(df9c)
#           D. Age minimum 3 employees fname,lname,age,prof
df9d=df.loc[df['location']=='india'].sort_values(by='age') [['fname','lname','age','prof']].head(3)
print(df9d)
#           E. age above 40 full data
df9e=df.loc[df['age']>40] [['id','fname','lname','age','prof','location']]
print(df9e)
#           F. age range 30 to 40 [profession count]
df9f=df.loc[(df['age']>=30)&(df['age']<=40)].groupby('prof')['prof'].count()
print(df9f)

# 10. us work
#          A. Row count
df10a=df.loc[df['location']=='us'].shape[0]
print(df10a)
#          B. Each age group count
df10b=df.loc[df['location']=='us'].groupby('age')['age'].count()
print(df10b)
#          C. Each profession count  [count desc]
df10c=df.loc[df['location']=='us'].groupby('prof')['prof'].count().sort_values(ascending=False)
print(df10c)
#          D. Civil engineer dept and age above 30
df10d=df.loc[(df['location']=='us')&(df['prof']=='Civil engineer')&(df['age']>30)]
print(df10d)