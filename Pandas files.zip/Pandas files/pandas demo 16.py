import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/sample4.txt",sep=',',header=None)
df.columns=['id','fname','lname','age','phno','location']
print(df)
#loc---to filter
# syntax newdfname=olddfname.loc[olddfname[colname]condition]
df1=df.loc[df['age']>23]
print(df1)
df2=df.loc[df['age']==21]
print(df2)

df3=df.loc[df['age']>23] [['fname','lname','age','phno']]
print(df3)

# below age 23----'fname','lname','age','phno'
df4=df.loc[df['age']<23] [['fname','lname','age','phno']]
print(df4)

# chennai working-----'fname','lname','age','phno'
df5=df.loc[df['location']=='Chennai'] [['fname','lname','age','phno']]
print(df5)

# above 23 and work chennai----'fname','lname','age','phno'
df6=df.loc[(df['age']>23) & (df['location']=='Chennai')] [['fname','lname','age','phno']]
print(df6)