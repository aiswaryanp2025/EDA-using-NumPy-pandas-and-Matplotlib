#nested dictionary into dataframe

import numpy as np
import pandas as pd
dic={'id':[1,2,3,4,5,6,7],'fname':['Aiswarya','Prayag','Athira','Anjali','Sidharth','Adithya','Amrita'],
     'lname':['N.P','Madhu','Nandakumar','kaipully','Ram','Cheral','Suresh'],'age':[25,27,25,26,25,20,23],
     'prof':['Data analyst','Software engineer','Teacher','Chemist','data analyst','Data scientist','Full stack developer'],
     'salary':[30000,35000,30000,35000,36000,34000,36000]}
df=pd.DataFrame(dic)
print(df)
