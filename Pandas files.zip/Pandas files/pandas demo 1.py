#Data structures ---three types
#1.Series
#2.Data frame
#3.Label or panel

#if the given dat is one dimensional data we convert it into series ----only rows present
# eg: list ,tuple,dictionary,set,1D array
#If given data is 2D—data frame is used
# Eg:excel file,csv file,txt file,json,nested list —rows and columns are present
#if given data is 3D ---label
#eg:image ,videos

import numpy as np
import pandas as pd
a=pd.Series([1,2,3,4,5])
print(a)
