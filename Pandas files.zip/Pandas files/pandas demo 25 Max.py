# syntax
# newdfname=olddfname.groupby('colname')[colname1].max()

import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)
df1=df.groupby('prof')['age'].max()
print(df1)
df2=df.groupby('prof')['age'].max().sort_values(ascending=False)
print(df2)

#calculate max age of persons working on each location
df3=df.groupby('location')['age'].max()
print(df3)

#India work--each profession max age

df4=df.loc[df['location']=='india']\
      .groupby('prof')['age'].max()\
      .sort_values(ascending=False)
print(df4)

# each profession min age---descending order
df5=df.groupby('prof')['age'].min().sort_values(ascending=False)
print(df5)

# us work-- each profession min age---ascending order
df5=df.loc[df['location']=='us'].groupby('prof')['age'].min()
print(df5)

#to calculate max or min of any one of the column

df6=df['age'].max()
print(df6)
df7=df['age'].min()
print(df7)

#each profession total age---sum()
df8=df.groupby('prof')['age'].sum()
print(df8)

##each profession average age---mean()
df8=df.groupby('prof')['age'].mean()
print(df8)

df9=df['age'].mean()
print(df9)