import numpy as np
import pandas as pd
a=pd.Series([2,3,4,6,5,1,7,9,8],index=[2,4,6,8,1,3,5,7,9])
print(a)