#head and tail in dictionary
import numpy as np
import pandas as pd
a=pd.Series({'id':101,'fname':'Aiswarya','lname':'N.P','age':25})
b=a.head(2)
c=a.tail(2)
print(b)
print(c)
print(a.dtype)

#in dictionary--- keys are the index
#we can define this index in the order we needed
a=pd.Series({'id':101,'fname':'Aiswarya','lname':'N.P','age':25},index=['age','id','fname','lname'])
print(a)