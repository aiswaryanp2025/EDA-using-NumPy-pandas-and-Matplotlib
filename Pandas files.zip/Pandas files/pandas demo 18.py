import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/missing_data.csv")
print(df)
print('_'*500)
print(df.shape)
print('_'*500)
print(df.dtypes)
print('_'*500)
print(df.isna().sum())
print('_'*500)
print(df.fillna(20))

