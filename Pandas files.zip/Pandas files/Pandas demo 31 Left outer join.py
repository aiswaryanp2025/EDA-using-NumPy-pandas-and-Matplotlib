import numpy as np
import pandas as pd
lst1=[[101,'Aiswarya','N.P',25],
     [102,'Adithya','C',21],
     [103,'Amrutha','S',23],
     [104,'Ashitha','Basheer',26],
     [105,'Anjali','K',26]]
df1=pd.DataFrame(lst1)
df1.columns=['id','fname','lname','age']
print(df1)
print('-'*500)
lst2=[['Data Analyst',103,'Thrissur',25000],
      ['Data Scientist',104,'Feroke', 25000],
      ['Big Data', 105, 'Shornur', 27000],
      ['Doctor', 106, 'Chelakkara', 55000],
      ['chemist', 107, 'Nattinchira', 30000]]
df2=pd.DataFrame(lst2)
df2.columns=['prof','id','location','salary']
print(df2)
print('-'*500)




#Left outer joining
# All the rows from left data frame and matching values from right
# Other values return as NaN
df3=pd.merge(df1,df2,on='id',how='left')
print(df3)

# Right outer join
# All the rows from right dataframe  and matching values from left
# Other values return as NaN

df4=pd.merge(df1,df2,on='id',how='right')
print(df4)

#Full outer join
# Combination of right and left
df5=pd.merge(df1,df2,on='id',how='outer')
print(df4)