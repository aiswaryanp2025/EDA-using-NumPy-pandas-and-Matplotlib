#Total number of missing values----data cleaning
import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)

print(df.isna().sum())

#we can manage missing values in different ways---filling and dropping
#filling
df1=df.fillna('India')
print (df1)
print(df1.isna().sum())