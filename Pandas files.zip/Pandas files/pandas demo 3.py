import numpy as np
import pandas as pd
a=pd.Series([12,3,5,4,6,7,9,25,20,35,8,40])
print(a)
print(a.ndim)
print(a.shape)
print(a.size)
print(a.head())
                       # ------ by default first 5 values is returned from the series
print(a.head(2))
print(a.tail())
                      #--------- by default last 5 values is returned
print(a.tail(3))