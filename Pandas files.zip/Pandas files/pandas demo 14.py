import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)
print('-'*1000)
df1=df[['fname','lname','age']].head(25)
df2=df[['fname','lname','age']].tail(20)
print(df1)
print('-'*1000)
print(df2)

#iloc function
#to collect particular row
print(df.iloc[3])
print(df.iloc[3:10])
print(df.iloc[3:50:3])

#also we can collect specific rows and columns using this function
print(df.iloc[3:10,:4])
