#custom_windows
#order_windows

# 1.join the data
# 2.Salary above 2000 name,age,salary,dat,amount
# 3.Age mxm 1 emp
# 4.Latest dat name age loca,dat,amount

import numpy as np
import pandas as pd
df1=pd.read_csv("C:/Users/aiswa/Downloads/custom_windows.csv")
df2=pd.read_csv("C:/Users/aiswa/Downloads/order_windows.csv")
print(df1)
print(df2)
# 1
df3=pd.merge(df1,df2,on='id',how='inner')
print(df3)
# 2
df4=pd.merge(df1,df2,on='id',how='inner')\
      .loc[df1['salary']>2000] \
       [['name','age','salary','dat','amount']]
print(df4)
# 3
df5=pd.merge(df1,df2,on='id',how='inner')\
      .sort_values(by='age',ascending=False)\
      [['name','age','salary','dat','amount']]\
      .head(1)
print(df4)
# 4
df6=pd.merge(df1,df2,on='id',how='inner')\
      .sort_values(by='dat',ascending=False)\
      [['name','location','age','dat','amount']]\
      .head(1)
