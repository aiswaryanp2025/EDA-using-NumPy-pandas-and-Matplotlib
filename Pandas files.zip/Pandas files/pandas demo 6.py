import numpy as np
import pandas as pd
a=pd.Series([1,2,3,4,5])
b=pd.Series([5,6,7,8,9])
c=a.add(b)
print(c)

#NaN-----Not a number ---represents missing value

a=pd.Series([1,2,3,4,5])
b=pd.Series([5,6,7,8,9])
c=a.sub(b)
print(c)

a=pd.Series([1,2,3,4,5])
b=pd.Series([5,6,7,8,9])
c=a.multiply(b)
print(c)

a=pd.Series([1,2,3,4,5])
b=pd.Series([5,6,7,8,9])
c=a.div(b)
print(c)