#Evaluating functions
# 1.Count
# Each columnwise count
import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/customer1.txt",sep=',',header=None )
df.columns=['id','fname','lname','age','prof','location']
print(df)
#syntax
#newdfname=olddfname.groupby('colname')['colname'].count()
df1=df.groupby('prof')['prof'].count()
print(df1)
df2=df.groupby('location')['location'].count()
print(df2)
#to get count in ascending or descending order
df3=df.groupby('location')['location'].count().sort_values()
print(df3)
df3=df.groupby('location')['location'].count().sort_values(ascending=False)
print(df3)

# india work--- each prof count--- sort
# Hierarchy order-====loc---group---count---sort---columns----head or tail
df4=df.loc[df['location']=='india']\
      .groupby('prof')['prof'].count()\
      .sort_values(ascending=False)
print(df4)

# age above 40 each location count[count desc]
df5=df.loc[df['age']>40]\
      .groupby('location')['location'].count()\
      .sort_values(ascending=False)
print(df5)

#age range 25 to 40 ,each profession[count desc]
df6=df.loc[(df['age']>=25) & (df['age']<=40)]\
      .groupby('prof')['prof'].count()\
      .sort_values(ascending=False)
print(df6)

# Max
# Min
# Sum
# Mean
