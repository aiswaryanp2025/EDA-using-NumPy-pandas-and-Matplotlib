import numpy as np
import pandas as pd
tup=(1,2,3,4,5,6)
a=pd.Series(tup)
print(a)

dic={'id':2,'fname':'Aiswarya','lname':'N.P','age':25}
j=pd.Series(dic)
print(j)
