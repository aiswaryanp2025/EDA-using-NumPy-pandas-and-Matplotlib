#Student name ,roll
#result roll res
# pass name roll res
import numpy as np
import pandas as pd
df1=pd.read_csv("C:/Users/aiswa/Downloads/student.csv")
df2=pd.read_csv("C:/Users/aiswa/Downloads/result.csv")
df3=pd.merge(df1,df2,on='roll',how='inner')\
      .loc[df2['res']=='pass']
print(df3)