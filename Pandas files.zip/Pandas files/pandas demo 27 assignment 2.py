#movies windows

import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/movies_windows.csv")
print(df)

# 1. Find row count
df1=df.shape[0]
print(df1)
# 2. Remove duplicates and find row count
df2=df.drop_duplicates().shape[0]
print(df2)
# 3. Sort data set by release year in des order
df3=df.sort_values(by='year',ascending =False)
print(df3)
# 4. Find rating mxm 5 movies name,year,rating
df4=df.sort_values(by='rating',ascending=False) [['name','year','rating']].head(5)
print(df4)
# 5. Find rating minimum 3 movies name,year,rating
df5=df.sort_values(by='rating') [['name','year','rating']].head(3)
print(df5)
# 6. Find Each year release movie count [count desc order]
df6=df.groupby('year')['year'].count().sort_values(ascending=False)
print(df6)
# 7. Each rating count [count desc order]
df7=df.groupby ('rating')['rating'].count().sort_values(ascending=False)
print(df7)
# 8. 2008 and rating above 3 [collect]
#              A. row count
df8=df.loc[(df['year']==2008) & (df['rating']>3)].shape[0]
print(df8)
# 9. Find duration mxm 1 movies name,year,rating,duration
df9=df.sort_values('duration',ascending=False) [['name','year','rating','duration']].head(1)
print(df9)
# 10. Find rating mnm 1 movies name,year,rating,duration
df10=df.sort_values('rating') [['name','year','rating','duration']].head(1)
print(df10)
# 11. Rating above 4 and relase year above 2005
#                 A. Rating mxm movies full data
df11a=df.loc[(df['rating']>4)&(df['year']>2005)].sort_values(by='rating',ascending=False).head(1)
print(df11a)
#                 B. Rating mnm movies full data
df11a=df.loc[(df['rating']>4)&(df['year']>2005)].sort_values(by='rating').head(1)
print(df11a)
# 12. 2008 movies count
df12=df.loc[(df['year']==2008)].groupby('year')['year'].count()
print(df12)
# 13. 1975-2000 movies collect
#           A. Row count
df13=df.loc[(df['year']>=1975)&(df['year']<=2000)].shape[0]
print(df13)
# 14. 1975-2000 and rating above 3.5 total row count
df13=df.loc[(df['year']>=1975)&(df['year']<=2000)&(df['rating']>3.5)].shape[0]
print(df13)