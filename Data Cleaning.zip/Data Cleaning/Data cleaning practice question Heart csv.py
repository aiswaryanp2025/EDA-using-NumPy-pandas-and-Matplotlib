#heart csv
#Create a dataframe
#1.Find total number of rows
#2.Print column names
#3.print first 5 rows
#4.print last 5 rows
#5.print dtypes
#6.Find target column count---desc
#7.seperate x and y
#8.Find  total number of missing values
#9.Fill the missing value in the proper method
#10.assume trest bps value >=170...fill it with mean value

import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/heart.csv")
#1.
df1=df.shape[0]
print(df1)
#2.
df2=df.columns
print(df2)
#3.
df3=df.head()
print(df3)
#4.
df4=df.tail()
print(df4)

#5.
df5=df.dtypes
print(df5)

#6.
df6=df.groupby('target')['target'].count().sort_values(ascending=False)
print(df6)

#7.
x=df.iloc[:,:-1]
y=df.iloc[:,-1]
print(x)
print(y)
print( )

#8.
df8=df.isna().sum()
print(df8)

#9.
print(df['trestbps'].unique())
print(df['restecg'].unique())
print(df['thalach'].unique())
print(df['ca'].unique())
print(df['thal'].unique())


f1=df['trestbps'].median()
f2=df['restecg'].mode()[0]
f3=df['thalach'].mean()
f4=df['ca'].mode()[0]
f5=df['thal'].mode()[0]


df['trestbps'].fillna(f1,inplace=True)
df['restecg'].fillna(f2,inplace=True)
df['thalach'].fillna(f3,inplace=True)
df['ca'].fillna(f4,inplace=True)
df['thal'].fillna(f5,inplace=True)
print(df.isna().sum())

#10.
x=df['trestbps'].mean()
for i in df.index:
    if df.loc[i,'trestbps']>=170:
        df.loc[i,'trestbps']=x
print(df)

df.to_csv("C:/Users/aiswa/Downloads/heart_cleaned.csv",index=False)






