# 1. How to handle missing Values
# 2. How to handle wrong data
# 3. How to handle wrong format data
import numpy as np
import pandas as pd
df=pd.read_csv('C:/Users/aiswa/Downloads/missing_data.csv')
print(df)
print(df.dtypes)
print(df.isna().sum())


# 1. How to handle missing Values
# fillna()
# If we need to make changes in the same data frame
# df.fillna(300,inplace=True)
# print(df)

# How to handle missing values of specific column
df['Calories'].fillna(310,inplace=True)
print(df.isna().sum())
print(df)

df['Date'].fillna('2020/12/22',inplace=True)
print(df)

# Missing values need to filled with logic
# Mean()
# Median----middle value after arranging in ascending order
# IF NUMBER OF ELEMENTS IS EVEN ----average of numbers at the middle
# Mode
# If missing value is numerical data—we can fill it using mean median or mode
# But for object data —only mode is used
# Even if it is numerical data only based on the column data we chose mean,mode or median
# unique() is used to get unique values in a df

print(df['Calories'].unique())

print('-'*200)
x=df['Calories'].mean()
print(x)
print('-'*200)
df['Calories'].fillna(x,inplace=True)
print (df)
print('-'*200)
y=df['Date'].mode()[0]     #0 is given because we have to choose zeroth index of most repeated values
print(y)

print('-'*200)
df['Date'].fillna(y,inplace=True)
print(df)