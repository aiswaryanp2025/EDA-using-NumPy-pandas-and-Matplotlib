#How to handle wrong format data


import numpy as np
import pandas as pd
df=pd.read_csv('C:/Users/aiswa/Downloads/missing_data.csv')
print(df)
df['Date']=pd.to_datetime(df['Date'],format='mixed')    #To convert into correct format
print(df)
df['Date'].fillna('20251105',inplace=True)             #date is added in correct format
print(df)