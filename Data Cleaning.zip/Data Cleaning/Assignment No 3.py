import numpy as np
import pandas as pd
df=pd.read_csv("C:/Users/aiswa/Downloads/txn_windows.csv")
print(df)

# 1. Find Row count
print(df.shape[0])
# 2. jan month oid,cusno,category,product,state
# A. Row count
df2=df.loc[df['dat'].str.startswith('01')]\
      [['oid','cuid','category','product','state']].shape[0]
print(df2)
# 3. July Month oid,cusno,category,product,state
# B. Row count
df3=df.loc[df['dat'].str.startswith('07')]\
      [['oid','cuid','category','product','state']].shape[0]
print(df3)
# 4. Each category [count desc sort]

df4=df.groupby('category')['category']\
      .count().sort_values(ascending=False)
print(df4)
# 5. Category full details
df5=df.loc[df['category']=='Outdoor Recreation']
print(df5)
# 6. Each paymethod count
df6=df.groupby('method')['method']\
      .count().sort_values(ascending=False)
print(df6)
# 7. jan-july month purchase count [include]
df7 = df.loc[df['dat'].dt.month.isin([1,2,3,4,5,6,7])].shape[0]
print(df7)
# 8. Each category total amount
df8=df.groupby('category')['pay_amount'].sum()
print(df8)
# 9. Each category maximum amount
df9=df.groupby('category')['pay_amount'].max()
print(df9)
# 10. Each category avg amount
df10=df.groupby('category')['pay_amount'].mean()
print(df10)
# 11.total amount by cash and credit card
df11=df.groupby('method')['pay_amount'].sum()
print(df11)
# 12. Indoor games ,total amount
df12=df.loc[df['category']=="Indoor Games"].groupby('category')['pay_amount'].sum()
print(df12)
# 13. Each state count
df13=df.groupby('state')['state'].count()
print(df13)