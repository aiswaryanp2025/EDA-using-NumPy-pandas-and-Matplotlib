#How to drop missing values---dropping rows having missing values

import numpy as np
import pandas as pd
df=pd.read_csv('C:/Users/aiswa/Downloads/missing_data.csv')
print(df)
print(df.dtypes)
print(df.isna().sum())
# df.dropna(inplace=True,ignore_index=True)                    #to get correct index ignore index is used
# print(df)

# df.dropna(subset='Calories',inplace=True,ignore_index=True)    #To drop specific rows
# print(df)

# missing value of Calories ---replace with mean
# Drop rows having missing value in date

x=df['Calories'].mean()
df.fillna(x,inplace=True)
print(df)
df.dropna(subset='Date',inplace=True,ignore_index=True)
print(df)


