# How to handle wrong data(outliers)====wrong info in data=eg:Height weight,heartbeat

import numpy as np
import pandas as pd
df=pd.read_csv('C:/Users/aiswa/Downloads/missing_data.csv')
print(df)
x=df['Duration'].mode()[0]
df.loc[7,'Duration']=x
print(df)

#Assume calories >400 is wrong data and replace it with mean

y=df['Calories'].mean()
for i in df.index:
    if df.loc[i,'Calories']>=400:
        df.loc[i,'Calories'] = y
print(df)