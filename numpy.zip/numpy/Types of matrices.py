#Zero matrices
#[0 0 0]
#[0 0 0]
         # (2,3)

#[0 0 0]
#[0 0 0]
#[0 0 0]
         # (3,3)

#[0 0 0 0 0]
          # (5,)

import numpy as np
a=np.zeros([3,3],dtype=int)
print(a)
print(a.ndim)

import numpy as np
a=np.zeros([4,5],dtype=int)
print(a)
print(a.ndim)