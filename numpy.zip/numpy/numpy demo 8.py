#to find total number of elements in an array
#size function

import numpy as np
a=np.array([1,2,3,4,5])
print(a)
print(a.size)

#to find data type of an array
print(a.dtype)

#to change datatype of all elements
a=np.array([1,2,3,4,5],dtype=float)
print(a)
print(a.dtype)

b=np.array([[2,2,2],[3,3,3],[4,4,4]])
print(b)
print(b.ndim)
print(b.size)