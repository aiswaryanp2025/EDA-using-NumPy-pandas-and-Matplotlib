#(5,4) matrice
#convert into4 by 5 matrix
#convert into 3D matrix
#convert into 1D

import numpy as np
a=np.array([[1,3,5,7,9],[2,4,6,8,2],[1,2,3,4,5],[5,6,7,8,9]])
print(a)
print('*'*100)
print(a.reshape([4,5]))
print('*'*100)
print(a.reshape([1,5,4]))
print('*'*100)
print(a.reshape([20]))
