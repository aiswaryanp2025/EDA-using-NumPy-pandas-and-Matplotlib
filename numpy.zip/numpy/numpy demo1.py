#Creating an array using numpy---n dimesnsional array
#What is dimension?
#number of axis
#one dimension ====> one axis ====>(x,)  eg: list,tuple,set,dictionary
#two dimension ====> two axis ====>(x,y) eg:
#three dimension ====> three axis ====> (z,x,y)

#order

#[4 5 6 6]
#[5 6 7 8]
#[1 2 3 4]
           #(3,4) === 2D

#[1 2 3 4 5]
#[5 4 3 2 1]
#[6 7 8 9 5]
#[5 4 3 2 1]
            #(4,5)

#[2 5 4 6]
          #(4,) ==== 1D