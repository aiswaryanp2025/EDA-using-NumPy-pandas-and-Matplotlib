#Create a 2D matrice of order 4x5
import numpy as np
a=np.array([[1,2,3,4,5],[6,7,8,9,10],[2,4,6,8,10],[1,3,5,7,9]])
print(a)
print(a.ndim)
print(a.shape)

# create a 2D array of order 3x4

import numpy as np
b=np.array([[1,4,3,5],[3,2,6,5],[9,8,7,6]])
print(b)
print(b.ndim)
print(b.shape)