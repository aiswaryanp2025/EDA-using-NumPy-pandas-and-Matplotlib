#create 3D matrix
import numpy as np
a=np.array([[[1,2,3,4],[4,5,6,7],[2,4,6,8]]])
print(a)
print(a.ndim)
print(a.shape)