#Create a zero matrix on 1 D
import numpy as np
a=np.zeros([5],dtype=int)
print(a)
print(a.ndim)

#create a zero matrix in 3D
import numpy as np
a=np.zeros([1,4,5],dtype=int)
print(a)
print(a.ndim)
print(a.shape)


import numpy as np
a=np.zeros([2,4,5],dtype=int)     #z times that matrice is printed
print(a)
print(a.size)
