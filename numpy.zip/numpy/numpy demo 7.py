#create 3d (4,4) matrix
import numpy as np
a=np.array([[[1,2,3,4],[4,3,2,1],[4,5,6,7],[7,6,5,4]]])
print(a)
print(a.ndim)
print(a.shape)