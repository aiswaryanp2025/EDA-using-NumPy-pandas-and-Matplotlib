#ones matrices
#[1 1 1 1]
#[1 1 1 1]      (2,4)

#[1 1 1]
#[1 1 1]
#[1 1 1]        (3,3)

#2D matrice
import numpy as np
a=np.ones([3,4],dtype=int)
print(a)

#1D matrice
import numpy as np
a=np.ones([5],dtype=int)
print(a)

#3D materice
import numpy as np
a=np.ones([1,3,5],dtype=int)
print(a)