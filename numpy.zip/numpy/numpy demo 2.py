import numpy as np
a=np.array([4,5,6,7,8,10])
print(a)
print(type(a))
print(a.ndim)                                      #ndim function to print dimension of array
print(a.shape)                                                   #shape function to print order of array
