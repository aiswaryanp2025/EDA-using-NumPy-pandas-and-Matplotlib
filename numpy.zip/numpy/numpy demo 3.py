#create an order 10 array
import numpy as np
a=np.array([2,4,6,8,10,12,14,16,18,20])
print(a)
print(a.ndim)
print(a.shape)